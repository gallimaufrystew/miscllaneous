/*
 * File:   tunnels.c
 * Author: huxingkan
 */

#include "help.h"

int main(int argc, char **argv)
{
    long timeout = 1000;
    int maxfd = -1, new_max_fd;
    bool running = true;
    fd_set fdset;
    struct timeval tv;
    struct sigaction sa;

    std::vector<int> fdv;

    ssl_session_t ssl_session;
    ssl_session.verify_peer = false;
    ssl_session.connected = false;
    ssl_session.connected_count = 0;

    maxfd = ssl_session.fd = open_ssl(443);

    printf("ssl fd %d\n", ssl_session.fd);

    //FD_SET(ssl_session.fd, &fdset);

    puts("start...");

    //FD_SET(STDIN_FILENO, &fdset);

    fdv.push_back(STDIN_FILENO);
    fdv.push_back(ssl_session.fd);

    sa.sa_handler = SIG_IGN;
    sa.sa_flags = 0;

    if (sigemptyset(&sa.sa_mask) == 0) {
        if (sigaction(SIGPIPE, &sa, 0) == -1) {
            perror("sigaction() fail");
            exit(EXIT_FAILURE);
        }
    }

    while (running) {

        tv.tv_sec = timeout;
        tv.tv_usec = 0;

        FD_ZERO(&fdset);

        for (int i = 0; i < fdv.size(); ++i) {
            maxfd = std::max(maxfd, fdv[i]);
            FD_SET(fdv[i], &fdset);
        }
        //FD_SET(maxfd, &fdset);

        if (select(maxfd + 1, &fdset, NULL, NULL, &tv) == 0) {
            //printf("%ld elapsed,timeout\n", timeout);
        } else {

            //puts("11");

            if (FD_ISSET(0, &fdset)) {
                puts("key input");
                //getchar();
                //running = false;
            }

            for (int i = 0; i < maxfd + 1; i++) {

                //puts("22");

                if (i == ssl_session.fd && FD_ISSET(ssl_session.fd, &fdset)) {

                    //puts("333");

                    if (!ssl_session.connected) {
                        if (ssl_session.connected_count) {
                            // cleanup previously claimed resources
                            //SSL_shutdown(ssl_session.ssl);
                            //SSL_free(ssl_session.ssl);

                            //SSL_CTX_free(ssl_session.ssl_old_ctx);
                            //SSL_CTX_free(ssl_session.ssl_new_ctx);
                            //close(ssl_session.client);
                        }

                        //puts("handle_ssl_client");

                        handle_ssl_client(&ssl_session);

                        fdv.push_back(ssl_session.client);

                        //puts("handle_ssl_client 1");

                        //new_max_fd = std::max(maxfd, ssl_session.client);
                    } else {
                        int fd = accept(ssl_session.fd, NULL, 0);
                        close(fd);
                        puts("only one ssl connection was allowed");
                    }
                } else if (i
                           == ssl_session.client && FD_ISSET(ssl_session.client, &fdset)) {

                    //puts("server ssl read");

                    int up_fd = handle_ssl_read(&ssl_session);
                    if (up_fd > 0) {
                        //new_max_fd = std::max(maxfd, up_fd);
                        fdv.push_back(up_fd);
                        //FD_SET(up_fd, &fdset);
                    }
                } else if (FD_ISSET(i, &fdset)) {
                    handle_upstream_read(i, &ssl_session);
                }
            }

            //maxfd = new_max_fd;
        }
    }

    SSL_shutdown(ssl_session.ssl);
    SSL_free(ssl_session.ssl);

    SSL_CTX_free(ssl_session.ssl_old_ctx);
    SSL_CTX_free(ssl_session.ssl_new_ctx);

    for (int i = 0; i < maxfd + 1; ++i) {
        close(i);
    }

    return 0;
}
