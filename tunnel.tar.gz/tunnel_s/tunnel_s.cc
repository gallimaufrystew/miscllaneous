
#include "tunnel_s.hpp"

int main(/*int argc, char* argv[]*/)
{
    /*
       if (argc != 5)
       {
          std::cerr << "usage: tcpproxy_server <local host ip> <local port> <forward host ip> <forward port>" << std::endl;
          return 1;
       }

       const unsigned short local_port   = static_cast<unsigned short>(::atoi(argv[2]));
       const unsigned short forward_port = static_cast<unsigned short>(::atoi(argv[4]));
       const std::string local_host      = argv[1];
       const std::string forward_host    = argv[3];
    */

    boost::asio::io_context io_context;

    try {
        ssl_tunnel_s::bridge::ssl_acceptor ssl_acceptor_one(io_context,
                "0.0.0.0", 1122,
                "127.0.0.1", 5555);
        ssl_acceptor_one.accept_connections();

        ssl_tunnel_s::bridge::ssl_acceptor ssl_acceptor_two(io_context,
                "0.0.0.0", 2233,
                "127.0.0.1", 5555);
        ssl_acceptor_two.accept_connections();

        ssl_tunnel_s::bridge::ssl_acceptor ssl_acceptor_three(io_context,
                "0.0.0.0", 3344,
                "127.0.0.1", 5555);
        ssl_acceptor_three.accept_connections();

        io_context.run();
    } catch (std::exception &e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
