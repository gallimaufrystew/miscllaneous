
#ifndef SSL_TUNNEL_C_H
#define SSL_TUNNEL_C_H

#include <cstdlib>
#include <cstddef>
#include <iostream>
#include <string>

#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/asio/ssl.hpp>

namespace ssl_tunnel_c {

namespace ip = boost::asio::ip;

class bridge : public boost::enable_shared_from_this<bridge>
{
public:

    typedef ip::tcp::socket socket_type;
    typedef boost::shared_ptr<bridge> session_ptr;

    bridge(boost::asio::io_context &io_context, boost::asio::ssl::context &ssl_context)
        : downstream_socket_(io_context),
          upstream_socket_(io_context, ssl_context)
    {
        upstream_socket_.set_verify_mode(boost::asio::ssl::verify_peer);
        upstream_socket_.set_verify_callback(boost::bind(&bridge::verify_certificate, this, _1, _2));
    }

    bool verify_certificate(bool preverified,
                            boost::asio::ssl::verify_context &ctx)
    {
        // In this example we will simply print the certificate's subject name.
        char subject_name[256];
        X509 *cert = X509_STORE_CTX_get_current_cert(ctx.native_handle());
        X509_NAME_oneline(X509_get_subject_name(cert), subject_name, 256);

        std::cout << "verify callback " << subject_name << "\n";

        return preverified;
    }

    socket_type &downstream_socket()
    {
        return downstream_socket_;
    }

    boost::asio::ssl::stream<socket_type> &upstream_socket()
    {
        return upstream_socket_;
    }

    void start(const std::string &upstream_host, const std::string &upstream_port)//unsigned short upstream_port)
    {
        boost::asio::ip::tcp::resolver resolver(upstream_socket_.get_io_service());
        boost::asio::ip::tcp::resolver::results_type endpoints =
            resolver.resolve(upstream_host, upstream_port);

        async_connect(upstream_socket_.lowest_layer(), endpoints,
                      boost::bind(&bridge::handle_connect, shared_from_this(),
                                  boost::asio::placeholders::error));
    }

    void handle_connect(const boost::system::error_code &error)
    {
        if (!error) {
            upstream_socket_.async_handshake(boost::asio::ssl::stream_base::client,
                                             boost::bind(&bridge::handle_upstream_connect, shared_from_this(),
                                                     boost::asio::placeholders::error));
        } else {
            std::cout << "async_handshake() failed: " << error.message() << "\n";
            close();
        }
    }

    void handle_upstream_connect(const boost::system::error_code &error)
    {
        if (!error) {
            upstream_socket_.async_read_some(
                boost::asio::buffer(up_stream_buf_, max_buf_size),
                boost::bind(&bridge::handle_upstream_read,
                            shared_from_this(),
                            boost::asio::placeholders::error,
                            boost::asio::placeholders::bytes_transferred));

            downstream_socket_.async_read_some(
                boost::asio::buffer(down_stream_buf_, max_buf_size),
                boost::bind(&bridge::handle_downstream_read,
                            shared_from_this(),
                            boost::asio::placeholders::error,
                            boost::asio::placeholders::bytes_transferred));
        } else {
            close();
        }
    }

private:

    void handle_downstream_write(const boost::system::error_code &error)
    {
        if (!error) {
            upstream_socket_.async_read_some(
                boost::asio::buffer(up_stream_buf_, max_buf_size),
                boost::bind(&bridge::handle_upstream_read,
                            shared_from_this(),
                            boost::asio::placeholders::error,
                            boost::asio::placeholders::bytes_transferred));
        } else {
            close();
        }
    }

    void handle_downstream_read(const boost::system::error_code &error,
                                const size_t &bytes_transferred)
    {
        if (!error) {
            async_write(upstream_socket_,
                        boost::asio::buffer(down_stream_buf_, bytes_transferred),
                        boost::bind(&bridge::handle_upstream_write,
                                    shared_from_this(),
                                    boost::asio::placeholders::error));
        } else {
            close();
        }
    }

    void handle_upstream_write(const boost::system::error_code &error)
    {
        if (!error) {
            downstream_socket_.async_read_some(
                boost::asio::buffer(down_stream_buf_, max_buf_size),
                boost::bind(&bridge::handle_downstream_read,
                            shared_from_this(),
                            boost::asio::placeholders::error,
                            boost::asio::placeholders::bytes_transferred));
        } else {
            close();
        }
    }

    void handle_upstream_read(const boost::system::error_code &error,
                              const size_t &bytes_transferred)
    {
        if (!error) {
            async_write(downstream_socket_,
                        boost::asio::buffer(up_stream_buf_, bytes_transferred),
                        boost::bind(&bridge::handle_downstream_write,
                                    shared_from_this(),
                                    boost::asio::placeholders::error));
        } else {
            close();
        }
    }

    void close()
    {
        boost::mutex::scoped_lock lock(mutex_);

        if (downstream_socket_.is_open()) {
            downstream_socket_.close();
        }

        //upstream_socket_.async_shutdown();
        //if (upstream_socket_.is_open())
        //{
        //   upstream_socket_.close();
        //}
    }

    socket_type downstream_socket_;
    boost::asio::ssl::stream<socket_type> upstream_socket_;

    //socket_type upstream_socket_;

    enum { max_buf_size = 8192 }; //8KB
    unsigned char down_stream_buf_[max_buf_size];
    unsigned char up_stream_buf_[max_buf_size];

    boost::mutex mutex_;

public:

    class acceptor
    {
    public:

        acceptor(boost::asio::io_service &io_service,
                 const std::string &local_host, unsigned short local_port,
                 const std::string &upstream_host, const std::string &upstream_port)
            : io_service_(io_service),
              localhost_address(boost::asio::ip::address_v4::from_string(local_host)),
              acceptor_(io_service_, ip::tcp::endpoint(localhost_address, local_port)),
              upstream_port_(upstream_port),
              upstream_host_(upstream_host)
        {}

        bool accept_connections()
        {
            try {
                boost::asio::ssl::context ssl_ctx(boost::asio::ssl::context::sslv23);
                ssl_ctx.load_verify_file("ca_sha2.crt");

                session_ = boost::shared_ptr<bridge>(new bridge(io_service_, ssl_ctx));

                acceptor_.async_accept(session_->downstream_socket(),
                                       boost::bind(&acceptor::handle_accept,
                                                   this,
                                                   boost::asio::placeholders::error));
            } catch (std::exception &e) {
                std::cerr << "acceptor exception: " << e.what() << std::endl;
                return false;
            }

            return true;
        }

    private:

        void handle_accept(const boost::system::error_code &error)
        {
            if (!error) {
                session_->start(upstream_host_, upstream_port_);
                if (!accept_connections()) {
                    std::cerr << "Failure during call to accept." << std::endl;
                }
            } else {
                std::cerr << "Error: " << error.message() << std::endl;
            }
        }

        boost::asio::io_service &io_service_;
        ip::address_v4 localhost_address;
        ip::tcp::acceptor acceptor_;
        session_ptr session_;
        //unsigned short upstream_port_;
        std::string upstream_port_;
        std::string upstream_host_;
    };
};
}

#endif
