
#include <cstdlib>
#include <cstddef>
#include <iostream>
#include <string>

#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/asio/ssl.hpp>

#include "tunnel_c.hpp"

int main(/*int argc, char *argv[]*/)
{
/*
    if (argc != 5) {
        std::cerr << "usage: tunnel_c <local host ip> <local port> <forward host ip> <forward port>" << std::endl;
        return 1;
    }

    const unsigned short local_port   = static_cast<unsigned short>(::atoi(argv[2]));

    //const unsigned short forward_port = static_cast<unsigned short>(::atoi(argv[4]));

    const std::string local_host      = argv[1];
    const std::string forward_host    = argv[3];
*/
    boost::asio::io_context io_context;

    try {
        ssl_tunnel_c::bridge::acceptor acceptor_one(io_context,
                                              "0.0.0.0",1031,
                                              "127.0.0.1","1122");
        acceptor_one.accept_connections();

        ssl_tunnel_c::bridge::acceptor acceptor_two(io_context,
                                              "0.0.0.0",1032,
                                              "127.0.0.1","2233");
        acceptor_two.accept_connections();

        ssl_tunnel_c::bridge::acceptor acceptor_three(io_context,
                                              "0.0.0.0",1033,
                                              "127.0.0.1","3344");
        acceptor_three.accept_connections();

        io_context.run();
    } catch (std::exception &e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
